# SAMM Class: setup guide (about 30 minutes)

This folder is the complete SAMM Class website and installable app.
- public/ is the website and app
- firestore.rules is the security (who can see and change what)
- firebase.json tells Firebase how to publish it

## What you need
- A Google account (use info.sammacademy@gmail.com)
- A computer with Node.js installed (nodejs.org, the LTS version)
Everything below is free on Firebase's Spark plan to start.

## Step 1. Create the Firebase project
1. Go to console.firebase.google.com and sign in.
2. Add project, name it SAMM Class, then continue (Google Analytics can be off).
3. Left menu, Build, Authentication, Get started, turn on Email/Password.
4. Left menu, Build, Firestore Database, Create database, choose a location close to Nigeria (europe-west is fine), start in production mode.

## Step 2. Connect the app to your project
1. Project settings (the gear), General, scroll to Your apps, click the web icon (</>), name it SAMM Class web, register.
2. Copy the firebaseConfig values it shows.
3. Open public/firebase-config.js and paste each value over the PASTE_... text. Save.
4. Check headEmail is the email you will use as head admin (default info.sammacademy@gmail.com).
   If you change it, change the same email in firestore.rules (it appears once, near the top).

## Step 3. Publish it
In a terminal inside this folder:
    npm install -g firebase-tools
    firebase login
    firebase use --add        (pick SAMM Class)
    firebase deploy
When it finishes you get your website link (yourproject.web.app). This also publishes the security rules.

## Step 4. Create the head admin account (do this first, before sharing the link)
1. Open your link, tap "I am an admin or tutor", register with the head admin email.
2. Firebase emails you a confirmation link. Tap it, then in the app tap "I have confirmed it".
3. You are now Head admin. Requests from admins and tutors appear in Account, under "Requests waiting for you".

## Step 5. Add classes and open to students
- Classes tab, Add class: title, level, time. Online classes open the live class room inside the app.
- Learn tab: add recorded lesson, notes and past-question links (YouTube, Google Drive).
- Quizzes tab: type questions in the format shown.
- Send students the link. They tap "I am a student", register, and see their level's classes.

## Put it on phones
- Android: open the link in Chrome, menu, Install app (or Add to Home screen).
- iPhone: open the link in Safari, Share, Add to Home Screen.
It then opens full screen with the SAMM icon like any app.
To list it in Google Play and the App Store, a developer wraps this same code (Capacitor does it), using a Play Console account (one-time fee) and an Apple Developer account (yearly fee). The code does not need rewriting.

## Live classes: read this
The class room uses the free public Jitsi server (meet.jit.si). It works with no setup, but the free public server can limit embedded rooms to short sessions.
For full-length classes, pick one:
1. Self-host Jitsi on a small server (a developer can do this in a few hours), then set videoDomain in firebase-config.js to your server name.
2. Use a paid video service (for example Jitsi as a Service, Daily, 100ms or Agora). This needs a small code change for that service.
Test one full-length class with your 100 Level group before relying on it.

## Known limits
- Recorded lessons and notes are links. Uploading files straight into the app needs Firebase Storage, which requires the paid Blaze plan.
- Payments are marked by an admin by hand. Paystack or Flutterwave can be added later.
- Only one head admin. Admins and tutors you approve can add classes and materials.
